# FFR: Find, Fix, Reason — Context Repair for Video Reasoning

This repository implements the **FFR (Find, Fix, Reason)** framework, which leverages a frozen, tool-integrated teacher model to perform observation-level intervention for video reasoning. The teacher diagnoses missing spatiotemporal dependencies in failed rollouts and supplies minimal evidence patches, while the student re-answers with the added context. Training updates via Group Relative Policy Optimization (GRPO) with a Robust Improvement Reward (RIR).

## Repository Structure

```
FFR-code/
├── ffr/                    # Main Python package
│   ├── train/              # Training entry points
│   │   ├── grpo.py         # GRPO training with FFR
│   │   ├── sft.py          # Supervised fine-tuning
│   │   └── rewards.py      # Reward functions
│   ├── trainer/            # Custom trainers
│   │   ├── grpo_trainer.py # GRPO trainer (DeepSpeed)
│   │   └── vllm_grpo_trainer.py  # vLLM-based GRPO trainer
│   ├── teacher/            # Teacher model API
│   │   ├── server.py       # FastAPI server
│   │   ├── model.py        # Teacher model core
│   │   ├── prompts.py      # Prompt templates
│   │   └── video_utils.py  # Video processing utilities
│   ├── eval/               # Evaluation
│   │   ├── eval_bench.py   # Benchmark evaluation runner
│   │   └── collect_results.py  # Results aggregation
│   └── data/               # Data utilities
│       └── preprocess.py   # SFT data preprocessing
├── scripts/                # Shell scripts
│   ├── train_grpo.sh       # GRPO training launcher
│   ├── train_sft.sh        # SFT training launcher
│   ├── run_eval.sh         # Evaluation launcher
│   └── run_ablation.sh     # Ablation study (parameterized)
├── configs/                # Configuration files
│   └── deepspeed/          # DeepSpeed configs
│       ├── zero2.json
│       ├── zero3.json
│       └── zero3_offload.json
└── data/                   # Data directory (not tracked)
```

## Quick Start

### 1. Environment Setup

```bash
# Set environment variables (see scripts/train_grpo.sh for full list)
export PYTHON_ENV=/path/to/your/conda/envs/ffr/bin
export MODEL_PATH=/path/to/Qwen2.5-VL-7B-COT-SFT
export VIDEO_DATA_PATH=/path/to/Video-R1-data
```

### 2. Training with FFR (GRPO + Teacher)

```bash
bash scripts/train_grpo.sh
```

### 3. SFT Training

```bash
bash scripts/train_sft.sh
```

### 4. Evaluation

```bash
bash scripts/run_eval.sh --model_path /path/to/checkpoint --output_dir ./eval_outputs
```

### 5. Ablation Study (Patch Tax)

```bash
# Run with specific kappa value
bash scripts/run_ablation.sh --patch_tax 0.3
```

## Key Components

### FFR Framework

The FFR framework operates within the GRPO training loop:

1. **Find**: For each failed rollout, the frozen teacher model identifies the missing spatiotemporal dependency.
2. **Fix**: The teacher generates a minimal evidence patch (key frames, temporal markers, spatial regions) without revealing the answer.
3. **Reason**: The student re-answers with the evidence patch; training updates via the Robust Improvement Reward (RIR).

### Robust Improvement Reward (RIR)

```
R̃_i = z_i * (R(τ_i) + R_fmt(τ_i)) + (1 - z_i) * (R(τ_i*) + R_fmt(τ_i*) - κ)
```

where `κ` is the patch tax that penalizes reliance on teacher patches.

### Teacher API

The teacher model runs as a separate FastAPI service. Configure via environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `API_KEY` | *(required)* | API key for teacher model service |
| `API_BASE` | `https://api.siliconflow.cn/v1` | API base URL |
| `MODEL_NAME` | `zai-org/GLM-4.5V` | Teacher model name |
| `TIMEOUT_SECONDS` | `45` | Request timeout |

## Configuration

All hardcoded paths have been replaced with environment variables or command-line arguments. See `scripts/train_grpo.sh` for a complete example.

## Citation

```bibtex
@inproceedings{ffr2026,
  title={Find, Fix, Reason: Context Repair for Video Reasoning},
  booktitle={ICML},
  year={2026}
}
```
