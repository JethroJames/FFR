import os
import textwrap
from collections import defaultdict
from typing import Any, Callable, Optional, Union
import random

import torch
import torch.utils.data
import transformers
from datasets import Dataset, IterableDataset
from packaging import version
from transformers import (
    AriaForConditionalGeneration,
    AriaProcessor,
    AutoModelForCausalLM,
    AutoModelForSequenceClassification,
    AutoProcessor,
    AutoTokenizer,
    GenerationConfig,
    PreTrainedModel,
    PreTrainedTokenizerBase,
    Qwen2VLForConditionalGeneration,
    Qwen2_5_VLForConditionalGeneration,
    Trainer,
    TrainerCallback,
    is_wandb_available,
)
from transformers.integrations.deepspeed import is_deepspeed_zero3_enabled
from transformers.utils import is_peft_available

from trl.data_utils import apply_chat_template, is_conversational, maybe_apply_chat_template
from trl.models import create_reference_model, prepare_deepspeed, unwrap_model_for_generation
from trl.trainer.grpo_config import GRPOConfig
from trl.trainer.utils import generate_model_card, get_comet_experiment_url

from qwen_vl_utils import process_vision_info

import copy

if is_peft_available():
    from peft import PeftConfig, get_peft_model

if is_wandb_available():
    import wandb

# What we call a reward function is a callable that takes a list of prompts and completions and returns a list of
# rewards. When it's a string, it's a model ID, so it's loaded as a pretrained model.
RewardFunc = Union[str, PreTrainedModel, Callable[[list, list], list[float]]]


class Qwen2VLGRPOTrainer(Trainer):
    """
    Trainer for the Group Relative Policy Optimization (GRPO) method. This algorithm was initially proposed in the
    paper [DeepSeekMath: Pushing the Limits of Mathematical Reasoning in Open Language Models](https://huggingface.co/papers/2402.03300).

    Example:

    ```python
    from datasets import load_dataset
    from trl import GRPOTrainer

    dataset = load_dataset("trl-lib/tldr", split="train")

    trainer = GRPOTrainer(
        model="Qwen/Qwen2-0.5B-Instruct",
        reward_funcs="weqweasdas/RM-Gemma-2B",
        train_dataset=dataset,
    )

    trainer.train()
    ```

    Args:
        model (`Union[str, PreTrainedModel]`):
            Model to be trained. Can be either:

            - A string, being the *model id* of a pretrained model hosted inside a model repo on huggingface.co, or
              a path to a *directory* containing model weights saved using
              [`~transformers.PreTrainedModel.save_pretrained`], e.g., `'./my_model_directory/'`. The model is
              loaded using [`~transformers.AutoModelForCausalLM.from_pretrained`] with the keywork arguments
              in `args.model_init_kwargs`.
            - A [`~transformers.PreTrainedModel`] object. Only causal language models are supported.
        reward_funcs (`Union[RewardFunc, list[RewardFunc]]`):
            Reward functions to be used for computing the rewards. To compute the rewards, we call all the reward
            functions with the prompts and completions and sum the rewards. Can be either:

            - A single reward function, such as:
                - A string: The *model ID* of a pretrained model hosted inside a model repo on huggingface.co, or a
                path to a *directory* containing model weights saved using
                [`~transformers.PreTrainedModel.save_pretrained`], e.g., `'./my_model_directory/'`. The model is loaded
                using [`~transformers.AutoModelForSequenceClassification.from_pretrained`] with `num_labels=1` and the
                keyword arguments in `args.model_init_kwargs`.
                - A [`~transformers.PreTrainedModel`] object: Only sequence classification models are supported.
                - A custom reward function: The function is provided with the prompts and the generated completions,
                  plus any additional columns in the dataset. It should return a list of rewards. For more details, see
                  [Using a custom reward function](#using-a-custom-reward-function).
            - A list of reward functions, where each item can independently be any of the above types. Mixing different
            types within the list (e.g., a string model ID and a custom reward function) is allowed.
        args ([`GRPOConfig`], *optional*, defaults to `None`):
            Configuration for this trainer. If `None`, a default configuration is used.
        train_dataset ([`~datasets.Dataset`] or [`~datasets.IterableDataset`]):
            Dataset to use for train. It must include a column `"prompt"`. Any additional columns in the dataset is
            ignored. The format of the samples can be either:

            - [Standard](dataset_formats#standard): Each sample contains plain text.
            - [Conversational](dataset_formats#conversational): Each sample contains structured messages (e.g., role
              and content).
        eval_dataset ([`~datasets.Dataset`], [`~datasets.IterableDataset`] or `dict[str, Union[Dataset, IterableDataset]]`):
            Dataset to use for evaluation. It must meet the same requirements as `train_dataset`.
        processing_class ([`~transformers.PreTrainedTokenizerBase`], *optional*, defaults to `None`):
            Processing class used to process the data. The padding side must be set to "left". If `None`, the
            processing class is loaded from the model's name with [`~transformers.AutoTokenizer.from_pretrained`].
        reward_processing_classes (`Union[PreTrainedTokenizerBase, list[PreTrainedTokenizerBase]]`, *optional*, defaults to `None`):
            Processing classes corresponding to the reward functions specified in `reward_funcs`. Can be either:

            - A single processing class: Used when `reward_funcs` contains only one reward function.
            - A list of processing classes: Must match the order and length of the reward functions in `reward_funcs`.
            If set to `None`, or if an element of the list corresponding to a [`~transformers.PreTrainedModel`] is
            `None`, the tokenizer for the model is automatically loaded using [`~transformers.AutoTokenizer.from_pretrained`].
            For elements in `reward_funcs` that are custom reward functions (not [`~transformers.PreTrainedModel`]),
            the corresponding entries in `reward_processing_classes` are ignored.
        callbacks (list of [`~transformers.TrainerCallback`], *optional*, defaults to `None`):
            List of callbacks to customize the train loop. Will add those to the list of default callbacks
            detailed in [here](https://huggingface.co/docs/transformers/main_classes/callback).

            If you want to remove one of the default callbacks used, use the [`~transformers.Trainer.remove_callback`]
            method.
        optimizers (`tuple[torch.optim.Optimizer, torch.optim.lr_scheduler.LambdaLR]`, *optional*, defaults to `(None, None)`):
            A tuple containing the optimizer and the scheduler to use. Will default to an instance of [`AdamW`] on your
            model and a scheduler given by [`get_linear_schedule_with_warmup`] controlled by `args`.
        peft_config ([`~peft.PeftConfig`], *optional*, defaults to `None`):
            PEFT configuration used to wrap the model. If `None`, the model is not wrapped.
    """

    def __init__(
            self,
            model: Union[str, PreTrainedModel],
            reward_funcs: Union[RewardFunc, list[RewardFunc]],
            args: GRPOConfig = None,
            script_args=None,
            train_dataset: Optional[Union[Dataset, IterableDataset]] = None,
            eval_dataset: Optional[Union[Dataset, IterableDataset, dict[str, Union[Dataset, IterableDataset]]]] = None,
            processing_class: Optional[PreTrainedTokenizerBase] = None,
            reward_processing_classes: Optional[Union[PreTrainedTokenizerBase, list[PreTrainedTokenizerBase]]] = None,
            callbacks: Optional[list[TrainerCallback]] = None,
            optimizers: tuple[Optional[torch.optim.Optimizer], Optional[torch.optim.lr_scheduler.LambdaLR]] = (
            None, None),
            peft_config: Optional["PeftConfig"] = None,
            max_pixels: Optional[int] = 12845056,
            min_pixels: Optional[int] = 3136,
            attn_implementation: str = "flash_attention_2",
            video_path_config: Optional[dict] = None,
            use_ffr: bool = False,
            teacher_api_url: str = "http://localhost:8000",
            teacher_api_nframes: int = 16,
            patch_tax: float = 0.0,
    ):
        # Args
        if args is None:
            model_name = model if isinstance(model, str) else model.config._name_or_path
            model_name = model_name.split("/")[-1]
            print("[Drop Last Batch] dataloader_drop_last has setted to True")
            args = GRPOConfig(f"{model_name}-GRPO", dataloader_drop_last=True)
        else:
            print("[Drop Last Batch] dataloader_drop_last has setted to True")
            args.dataloader_drop_last = True

        # Models
        # Trained model
        model_init_kwargs = args.model_init_kwargs or {}
        model_init_kwargs["attn_implementation"] = attn_implementation
        if isinstance(model, str):
            model_id = model
            torch_dtype = model_init_kwargs.get("torch_dtype")
            if isinstance(torch_dtype, torch.dtype) or torch_dtype == "auto" or torch_dtype is None:
                pass  # torch_dtype is already a torch.dtype or "auto" or None
            elif isinstance(torch_dtype, str):  # it's a str, but not "auto"
                torch_dtype = getattr(torch, torch_dtype)
                model_init_kwargs["torch_dtype"] = torch_dtype
            else:
                raise ValueError(
                    "Invalid `torch_dtype` passed to `GRPOConfig`. Expected either 'auto' or a string representing "
                    f"a `torch.dtype` (e.g., 'float32'), but got {torch_dtype}."
                )
            # Disable caching if gradient checkpointing is enabled (not supported)
            model_init_kwargs["use_cache"] = (
                False if args.gradient_checkpointing else model_init_kwargs.get("use_cache")
            )
            if "Qwen2-VL" in model_id:
                model = Qwen2VLForConditionalGeneration.from_pretrained(model, **model_init_kwargs)
            elif "Qwen2.5-VL" in model_id:
                model = Qwen2_5_VLForConditionalGeneration.from_pretrained(model, **model_init_kwargs)
            elif "Aria" in model_id:
                model_init_kwargs.pop("use_cache")
                model = AriaForConditionalGeneration.from_pretrained(model, **model_init_kwargs)
            else:
                model = Qwen2_5_VLForConditionalGeneration.from_pretrained(model, **model_init_kwargs)
        else:
            model_id = model.config._name_or_path
            if args.model_init_kwargs is not None:
                raise ValueError(
                    "You passed `model_init_kwargs` to the `GRPOConfig`, but your model is already instantiated. "
                    "This argument can only be used when the `model` argument is a string."
                )

        if peft_config is not None:
            model = get_peft_model(model, peft_config)

        # Reference model
        if is_deepspeed_zero3_enabled():
            if "Qwen2-VL" in model_id:
                self.ref_model = Qwen2VLForConditionalGeneration.from_pretrained(model_id, **model_init_kwargs)
            elif "Qwen2.5-VL" in model_id:
                self.ref_model = Qwen2_5_VLForConditionalGeneration.from_pretrained(model_id, **model_init_kwargs)
            elif "Aria" in model_id:
                self.ref_model = AriaForConditionalGeneration.from_pretrained(model_id, **model_init_kwargs)
            else:
                self.ref_model = Qwen2_5_VLForConditionalGeneration.from_pretrained(model_id, **model_init_kwargs)
        elif peft_config is None:
            # If PEFT configuration is not provided, create a reference model based on the initial model.
            self.ref_model = create_reference_model(model)
        else:
            # If PEFT is used, the reference model is not needed since the adapter can be disabled
            # to revert to the initial model.
            self.ref_model = None

        # Processing class
        if processing_class is None:
            if "Qwen2-VL" in model_id or "Qwen2.5-VL" in model_id or "Aria" in model_id or True:
                processing_class = AutoProcessor.from_pretrained(model_id)
                pad_token_id = processing_class.tokenizer.pad_token_id
                processing_class.pad_token_id = pad_token_id
                processing_class.eos_token_id = processing_class.tokenizer.eos_token_id
                if "Qwen" in model_id or "Qwen2.5-VL" in model_id:
                    processing_class.image_processor.max_pixels = max_pixels
                    processing_class.image_processor.min_pixels = min_pixels
            else:
                processing_class = AutoTokenizer.from_pretrained(model.config._name_or_path, padding_side="left")
                pad_token_id = processing_class.pad_token_id

        # Reward functions
        if not isinstance(reward_funcs, list):
            reward_funcs = [reward_funcs]
        for i, reward_func in enumerate(reward_funcs):
            if isinstance(reward_func, str):
                reward_funcs[i] = AutoModelForSequenceClassification.from_pretrained(
                    reward_func, num_labels=1, **model_init_kwargs
                )
        self.reward_funcs = reward_funcs

        # Reward processing class
        if reward_processing_classes is None:
            reward_processing_classes = [None] * len(reward_funcs)
        elif not isinstance(reward_processing_classes, list):
            reward_processing_classes = [reward_processing_classes]
        else:
            if len(reward_processing_classes) != len(reward_funcs):
                raise ValueError("The number of reward processing classes must match the number of reward functions.")

        for i, (reward_processing_class, reward_func) in enumerate(zip(reward_processing_classes, reward_funcs)):
            if isinstance(reward_func, PreTrainedModel):
                if reward_processing_class is None:
                    reward_processing_class = AutoTokenizer.from_pretrained(reward_func.config._name_or_path)
                if reward_processing_class.pad_token_id is None:
                    reward_processing_class.pad_token = reward_processing_class.eos_token
                # The reward model computes the reward for the latest non-padded token in the input sequence.
                # So it's important to set the pad token ID to the padding token ID of the processing class.
                reward_func.config.pad_token_id = reward_processing_class.pad_token_id
                reward_processing_classes[i] = reward_processing_class
        self.reward_processing_classes = reward_processing_classes

        # Data collator
        def data_collator(features):  # No data collation is needed in GRPO
            return features

        # Training arguments
        self.max_prompt_length = args.max_prompt_length
        self.max_completion_length = args.max_completion_length  # = |o_i| in the GRPO paper
        self.num_generations = args.num_generations  # = G in the GRPO paper
        self.generation_config = GenerationConfig(
            max_new_tokens=self.max_completion_length,
            do_sample=True,
            top_p=0.95,
            temperature=1,  # HACK
            num_return_sequences=self.num_generations,
            pad_token_id=pad_token_id,
        )
        self.shuffled_num_generations = self.num_generations // 2
        self.shuffled_generation_config = GenerationConfig(
            max_new_tokens=self.max_completion_length,
            do_sample=True,
            top_p=0.95,
            temperature=1,  # HACK
            num_return_sequences=self.shuffled_num_generations,
            pad_token_id=pad_token_id,
        )

        self.dummy_generation_config = GenerationConfig(
            max_new_tokens=1,
            do_sample=True,
            top_p=0.95,
            temperature=1,  # HACK
            num_return_sequences=1,
            pad_token_id=pad_token_id,
        )
        self.beta = args.beta

        # The trainer estimates the number of FLOPs (floating-point operations) using the number of elements in the
        # input tensor associated with the key "input_ids". However, in GRPO, the sampled data does not include the
        # "input_ids" key. Instead, the available keys is "prompt". As a result, the trainer issues the warning:
        # "Could not estimate the number of tokens of the input, floating-point operations will not be computed." To
        # suppress this warning, we set the "estimate_tokens" key in the model's "warnings_issued" dictionary to True.
        # This acts as a flag to indicate that the warning has already been issued.
        model.warnings_issued["estimate_tokens"] = True

        # Initialize the metrics
        self._metrics = defaultdict(list)

        # Store video path config
        self.video_path_config = video_path_config or {}

        # FFR (Find-Fix-Reason) configuration
        self.use_ffr = use_ffr
        self.teacher_api_url = teacher_api_url
        self.teacher_api_nframes = teacher_api_nframes
        self.patch_tax = patch_tax

        # FFR statistics counters (for logging)
        self._ffr_stats = {
            'total_rollouts': 0,
            'incorrect_rollouts': 0,
            'teacher_api_calls': 0,
            'teacher_api_success': 0,
            'fix_attempts': 0,
            'fix_success': 0,
            'total_prompt_tokens': 0,
            'total_completion_tokens': 0,
            'total_second_round_tokens': 0,
        }

        super().__init__(
            model=model,
            args=args,
            data_collator=data_collator,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            processing_class=processing_class,
            callbacks=callbacks,
            optimizers=optimizers,
        )

        # Gradient accumulation requires scaled loss. Normally, loss scaling in the parent class depends on whether the
        # model accepts loss-related kwargs. Since we compute our own loss, this check is irrelevant. We set
        # self.model_accepts_loss_kwargs to False to enable scaling.
        self.model_accepts_loss_kwargs = False

        if self.ref_model is not None:
            if self.is_deepspeed_enabled:
                self.ref_model = prepare_deepspeed(self.ref_model, self.accelerator)
            else:
                self.ref_model = self.accelerator.prepare_model(self.ref_model, evaluation_mode=True)

        for i, reward_func in enumerate(self.reward_funcs):
            if isinstance(reward_func, PreTrainedModel):
                self.reward_funcs[i] = self.accelerator.prepare_model(reward_func, evaluation_mode=True)

    def _set_signature_columns_if_needed(self):
        # If `self.args.remove_unused_columns` is True, non-signature columns are removed.
        # By default, this method sets `self._signature_columns` to the model's expected inputs.
        # In GRPOTrainer, we preprocess data, so using the model's signature columns doesn't work.
        # Instead, we set them to the columns expected by the `training_step` method, hence the override.
        if self._signature_columns is None:
            self._signature_columns = ["prompt"]

    # Get the per-token log probabilities for the completions for the model and the reference model
    def _get_per_token_logps(self, model, input_ids, **kwargs):
        logits = model(input_ids, **kwargs).logits
        logits = logits[:, :-1, :]  # (B, L-1, V), exclude the last logit: it corresponds to the next token pred
        input_ids = input_ids[:, 1:]  # (B, L-1), exclude the first input ID since we don't have logits for it
        # Compute the log probabilities for the input tokens. Use a loop to reduce memory peak.
        per_token_logps = []
        for logits_row, input_ids_row in zip(logits, input_ids):
            log_probs = logits_row.log_softmax(dim=-1)
            token_log_prob = torch.gather(log_probs, dim=1, index=input_ids_row.unsqueeze(1)).squeeze(1)
            per_token_logps.append(token_log_prob)
        return torch.stack(per_token_logps)

    def remove_none_from_data(self, data):
        for entry in data:
            if "content" in entry and isinstance(entry["content"], list):
                for sub_entry in entry["content"]:
                    if isinstance(sub_entry, dict):
                        keys_to_remove = [k for k, v in sub_entry.items() if v is None]
                        for k in keys_to_remove:
                            del sub_entry[k]
        return data

    def _call_teacher_api(self, problem_id, question, video_path, student_response,
                         student_score, ground_truth, data_source):
        """
        Call Teacher API to get evidence patch for incorrect rollout.

        Args:
            problem_id: Problem identifier
            question: The question text
            video_path: Relative video path
            student_response: Student model's response (text)
            student_score: Accuracy score (0 or 1)
            ground_truth: Correct answer
            data_source: Data source name for video path resolution

        Returns:
            evidence_text: Evidence patch content (str) or None if failed
        """
        import requests

        # Validate required fields - skip API call if critical data is missing
        if not question or not question.strip():
            print(f"[FFR] Skipping API call for {problem_id}: question is empty")
            return None

        if not student_response or not student_response.strip():
            print(f"[FFR] Skipping API call for {problem_id}: student_response is empty")
            return None

        # Get full video path
        video_base_path = self.video_path_config.get(data_source, "")
        full_video_path = os.path.join(video_base_path, video_path) if video_base_path else video_path

        # Use sensible defaults for optional fields
        request_data = {
            "problem_id": str(problem_id),
            "question": question.strip(),
            "video_path": full_video_path,
            "student_response": student_response.strip(),
            "student_score": float(student_score),
            "ground_truth": ground_truth.strip() if ground_truth else "No reference answer provided",
            "incorrect_only": False,
            "nframes": self.teacher_api_nframes
        }

        try:
            response = requests.post(
                f"{self.teacher_api_url}/analyze",
                json=request_data,
                timeout=60
            )
            if response.status_code == 200:
                result = response.json()
                if result["success"] and result.get("data"):
                    evidence = result["data"].get("evidence_patch", {})
                    evidence_content = evidence.get("content", "") if isinstance(evidence, dict) else ""
                    if evidence_content:
                        print(f"[FFR] Teacher API returned evidence for {problem_id}: {evidence_content[:100]}...")
                        return evidence_content

            # Detailed error logging for debugging
            print(f"[FFR] Teacher API failed for {problem_id}: status={response.status_code}")
            if response.status_code == 422:
                try:
                    error_detail = response.json()
                    print(f"[FFR] 422 Error details: {error_detail}")
                    print(f"[FFR] Request data sent: {request_data}")
                except:
                    print(f"[FFR] Response text: {response.text}")
            return None
        except Exception as e:
            print(f"[FFR] Teacher API call failed for {problem_id}: {e}")
            return None

    def _generate_second_round_completion(self, original_prompt_text, evidence, input_item,
                                          model, vision_inputs_for_ffr):
        """
        Generate second round completion with evidence patch.

        Args:
            original_prompt_text: Original prompt text (str)
            evidence: Evidence patch content (str)
            input_item: Original input dictionary
            model: The model to generate with
            vision_inputs_for_ffr: Dict with 'image_inputs' and 'video_inputs' (already processed from video files)

        Returns:
            completion_text: Generated completion text
            completion_ids: Generated token IDs (1D tensor)
        """
        # Construct new prompt with evidence
        evidence_instruction = (
            f"\n\nAdditional Information: Based on careful analysis, here is some relevant information "
            f"that may help you answer the question:\n{evidence}\n\n"
            f"Please reconsider the question with this additional context and provide your answer."
        )

        print(f"[FFR] Preparing second round inputs (reusing vision data to save time)...")

        # [FFR FIX] Reconstruct messages with evidence
        # We need to maintain the proper message structure for Qwen2.5-VL
        import copy
        second_round_messages = copy.deepcopy(input_item['prompt'])

        # Find the last user message and append evidence to it
        for msg in reversed(second_round_messages):
            if msg['role'] == 'user':
                # The content is a list with video/image and text elements
                for content_item in msg['content']:
                    if content_item.get('type') == 'text':
                        content_item['text'] += evidence_instruction
                        break
                break

        # Apply chat template to get the text with evidence
        second_round_text = self.processing_class.apply_chat_template(
            second_round_messages,
            tokenize=False,
            add_generation_prompt=True
        )

        # [FFR FIX] Use processor with pre-loaded vision inputs
        # This avoids re-reading video files while ensuring correct text+vision alignment
        second_prompt_inputs = self.processing_class(
            text=[second_round_text],
            images=vision_inputs_for_ffr['image_inputs'],
            videos=vision_inputs_for_ffr['video_inputs'],
            return_tensors="pt",
            padding=True,
            padding_side="left",
            add_special_tokens=False,
        )

        # Move to device using parent's _prepare_inputs method
        second_prompt_inputs = super()._prepare_inputs(second_prompt_inputs)

        # Truncate if needed
        if self.max_prompt_length is not None:
            second_prompt_inputs["input_ids"] = second_prompt_inputs["input_ids"][:, -self.max_prompt_length:]
            second_prompt_inputs["attention_mask"] = second_prompt_inputs["attention_mask"][:, -self.max_prompt_length:]

        # Generate (only 1 completion for second round)
        # Use shorter generation for second round to avoid timeout
        second_round_max_tokens = min(512, self.max_completion_length)
        single_gen_config = GenerationConfig(
            max_new_tokens=second_round_max_tokens,
            do_sample=True,
            top_p=0.95,
            temperature=1.0,
            num_return_sequences=1,
            pad_token_id=self.processing_class.pad_token_id,
            eos_token_id=self.processing_class.eos_token_id,
        )

        print(f"[FFR] Starting second round generation (max_tokens={second_round_max_tokens})...")

        try:
            with unwrap_model_for_generation(model, self.accelerator) as unwrapped_model:
                prompt_completion_ids = unwrapped_model.generate(**second_prompt_inputs, generation_config=single_gen_config)
                prompt_length = second_prompt_inputs["input_ids"].size(1)
                completion_ids = prompt_completion_ids[:, prompt_length:]
        except Exception as gen_error:
            print(f"[FFR ERROR] Generation failed: {gen_error}")
            import traceback
            traceback.print_exc()
            raise

        # Mask video tokens if present
        video_token_id = 151656
        completion_mask_for_video = (completion_ids == video_token_id)
        if completion_mask_for_video.any():
            completion_ids[completion_mask_for_video] = self.processing_class.pad_token_id

        # Decode completion
        completion_text = self.processing_class.batch_decode(completion_ids, skip_special_tokens=True)[0]

        print(f"[FFR] Second round completion: {completion_text[:100]}...")

        return completion_text, completion_ids.squeeze(0)

    # Trainer "prepares" the inputs before calling `compute_loss`. It converts to tensor and move to device.
    # Since we preprocess the data in `compute_loss`, we need to override this method to skip this step.
    def _prepare_inputs(self, inputs: dict[str, Union[torch.Tensor, Any]]) -> dict[str, Union[torch.Tensor, Any]]:
        return inputs

    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        if return_outputs:
            raise ValueError("The GRPOTrainer does not support returning outputs")

        prompts = [x["prompt"] for x in inputs]
        prompts_text = [maybe_apply_chat_template(example, self.processing_class)["prompt"] for example in inputs]

        input_copy = copy.deepcopy(inputs[0]['prompt'])

        input_copy = self.remove_none_from_data(input_copy)

        data_type = inputs[0]['data_type']
        if data_type == 'video':
            data_source = inputs[0]['data_source']
            video_name = inputs[0]['path']
            
            # Get video base path from config
            video_base_path = self.video_path_config.get(data_source, "")
            video_path = os.path.join(video_base_path, video_name) if video_base_path else video_name

            input_copy[0]['content'][0]['video'] = video_path
            input_copy[0]['content'][0]['nframes'] = 16
            input_copy[0]['content'][0]['max_pixels'] = 128 * 28 * 28

        image_inputs, video_inputs, video_kwargs = process_vision_info(input_copy, return_video_kwargs=True)

        # [FFR FIX] Save processed vision inputs for second round generation
        # This avoids re-reading video files while allowing processor to correctly handle text+vision
        if self.use_ffr:
            vision_inputs_for_ffr = {
                'image_inputs': image_inputs,
                'video_inputs': video_inputs,
            }
        else:
            vision_inputs_for_ffr = None

        prompt_inputs = self.processing_class(
            text=copy.deepcopy(prompts_text),
            images=image_inputs,
            videos=video_inputs,
            return_tensors="pt",
            padding=True,
            padding_side="left",
            add_special_tokens=False,
        )

        prompt_inputs = super()._prepare_inputs(prompt_inputs)

        # fix prompt_inputs["input_ids"] length issue
        if self.max_prompt_length is not None:
            prompt_inputs["input_ids"] = prompt_inputs["input_ids"][:, -self.max_prompt_length:]
            prompt_inputs["attention_mask"] = prompt_inputs["attention_mask"][:, -self.max_prompt_length:]

        prompt_ids, prompt_mask = prompt_inputs["input_ids"], prompt_inputs["attention_mask"]

        if self.max_prompt_length is not None:
            prompt_ids = prompt_ids[:, -self.max_prompt_length:]
            prompt_mask = prompt_mask[:, -self.max_prompt_length:]

        # Generate completions
        with unwrap_model_for_generation(model, self.accelerator) as unwrapped_model:
            prompt_completion_ids = unwrapped_model.generate(**prompt_inputs, generation_config=self.generation_config)
            prompt_length = prompt_ids.size(1)
            prompt_ids = prompt_completion_ids[:, :prompt_length]
            completion_ids = prompt_completion_ids[:, prompt_length:]

            ############################ mask video token generated by model ############################
            video_token_id = 151656
            completion_mask_for_video = (completion_ids == video_token_id)
            if completion_mask_for_video.any():
                completion_ids[completion_mask_for_video] = self.processing_class.pad_token_id
                prompt_completion_ids[:, prompt_length:] = completion_ids
            ############################ mask video token generated by model ############################

            prompt_mask = prompt_mask.repeat_interleave(self.num_generations, dim=0)

        print('path:', input_copy[0]['content'][0][inputs[0]['data_type']])
        print('problem_id:', inputs[0]['problem_id'])
        print('prompt_length:', prompt_length)

        # Mask everything after the first EOS token
        is_eos = completion_ids == self.processing_class.eos_token_id
        device = self.accelerator.device
        eos_idx = torch.full((is_eos.size(0),), is_eos.size(1), dtype=torch.long, device=device)
        eos_idx[is_eos.any(dim=1)] = is_eos.int().argmax(dim=1)[is_eos.any(dim=1)]
        sequence_indices = torch.arange(is_eos.size(1), device=device).expand(is_eos.size(0), -1)
        completion_mask = (sequence_indices <= eos_idx.unsqueeze(1)).int()

        # Concatenate prompt_mask with completion_mask for logit computation
        # attention_mask = torch.cat([prompt_mask, completion_mask], dim=1)  # (B*G, P+C)
        # pixel_values = prompt_inputs["pixel_values"].repeat(self.num_generations, 1)
        # image_grid_thw = prompt_inputs["image_grid_thw"].repeat_interleave(self.num_generations, dim=0)

        prompt_inputs.pop("input_ids")
        prompt_inputs.pop("attention_mask")

        if inputs[0]['data_type'] == 'image':
            prompt_inputs["pixel_values"] = prompt_inputs["pixel_values"].repeat(len(prompt_completion_ids), 1)
            prompt_inputs["image_grid_thw"] = prompt_inputs["image_grid_thw"].repeat(len(prompt_completion_ids), 1)

        if inputs[0]['data_type'] == 'video':
            prompt_inputs["pixel_values_videos"] = prompt_inputs["pixel_values_videos"].repeat(
                len(prompt_completion_ids), 1)
            prompt_inputs["video_grid_thw"] = prompt_inputs["video_grid_thw"].repeat(len(prompt_completion_ids), 1)
            if 'second_per_grid_ts' in prompt_inputs:
                del prompt_inputs["second_per_grid_ts"]

        try:
            per_token_logps = self._get_per_token_logps(model, prompt_completion_ids, **prompt_inputs)
            per_token_logps = per_token_logps[:, prompt_length - 1:]
        except Exception as e:
            print(f"Error computing per_token_logps: {e}. Setting output to zero.")
            per_token_logps = self._get_per_token_logps(model, prompt_completion_ids)

        with torch.inference_mode():
            try:
                if self.ref_model is not None:
                    ref_per_token_logps = self._get_per_token_logps(self.ref_model, prompt_completion_ids,
                                                                    **prompt_inputs)
                else:
                    with self.accelerator.unwrap_model(model).disable_adapter():
                        ref_per_token_logps = self._get_per_token_logps(model, prompt_completion_ids, **prompt_inputs)
                ref_per_token_logps = ref_per_token_logps[:, prompt_length - 1:]
            except Exception as e:
                print(f"Error computing ref_per_token_logps: {e}. Setting output to zero.")
                with self.accelerator.unwrap_model(model).disable_adapter():
                    ref_per_token_logps = self._get_per_token_logps(model, prompt_completion_ids)
                ref_per_token_logps = ref_per_token_logps[:, prompt_length - 1:]

        # Compute the KL divergence between the model and the reference model

        x_clamped = torch.clamp(ref_per_token_logps - per_token_logps, min=-10, max=10)
        per_token_kl = torch.exp(x_clamped) - x_clamped - 1

        # Decode the generated completions
        completions = self.processing_class.batch_decode(completion_ids, skip_special_tokens=True)
        if is_conversational(inputs[0]):
            completions = [[{"role": "assistant", "content": completion}] for completion in completions]

        # Compute the rewards
        prompts = [prompt for prompt in prompts for _ in range(self.num_generations)]
        rewards_per_func = torch.zeros(len(prompts), len(self.reward_funcs), device=device)
        for i, (reward_func, reward_processing_class) in enumerate(
                zip(self.reward_funcs, self.reward_processing_classes)
        ):
            # Repeat all input columns (but "prompt" and "completion") to match the number of generations
            reward_kwargs = {key: [] for key in inputs[0].keys() if key not in ["prompt", "completion"]}
            for key in reward_kwargs:
                for example in inputs:
                    # Repeat each value in the column for `num_generations` times
                    reward_kwargs[key].extend([example[key]] * self.num_generations)
            output_reward_func = reward_func(prompts=prompts, completions=completions, **reward_kwargs)
            rewards_per_func[:, i] = torch.tensor(output_reward_func, dtype=torch.float32, device=device)

        rewards = rewards_per_func.sum(dim=1)

        print(rewards)
        print(completion_mask.sum(1))

        # FFR (Find-Fix-Reason) Framework
        if self.use_ffr:
            print("[FFR] Applying Find-Fix-Reason framework...")

            # Synchronize all GPUs before starting FFR
            if torch.distributed.is_initialized():
                print(f"[FFR] Rank {torch.distributed.get_rank()} synchronizing before FFR...")
                torch.distributed.barrier()

            # Debug: Print available fields in inputs[0]
            print(f"[FFR DEBUG] Available keys in inputs[0]: {list(inputs[0].keys())}")

            # Get accuracy rewards (assuming accuracy is the first reward function)
            accuracy_rewards = rewards_per_func[:, 0]  # (B*G,)

            # Identify incorrect rollouts (z_i = 0 when accuracy < 1)
            correct_mask = (accuracy_rewards >= 1.0).float()  # (B*G,)

            # Since batch_size=1, we have exactly num_generations rollouts
            assert len(inputs) == 1, "FFR requires batch_size=1"

            # ==================== FFR Statistics ====================
            num_incorrect = int((correct_mask < 0.5).sum().item())
            self._ffr_stats['total_rollouts'] += self.num_generations
            self._ffr_stats['incorrect_rollouts'] += num_incorrect
            self._ffr_stats['total_prompt_tokens'] += prompt_length
            self._ffr_stats['total_completion_tokens'] += int(completion_mask.sum().item())
            # ========================================================

            # Collect evidence for each incorrect rollout
            corrected_rewards = rewards.clone()

            # [FFR FIX] Collect which rollouts need second round generation on THIS rank
            # We need to synchronize across all ranks to avoid DeepSpeed ZeRO-3 deadlock
            local_needs_generation = torch.zeros(self.num_generations, dtype=torch.bool, device=device)
            for rollout_idx in range(self.num_generations):
                if correct_mask[rollout_idx].item() < 0.5:
                    local_needs_generation[rollout_idx] = True

            # [FFR FIX] Gather information from all ranks to determine which rollouts need generation
            # If ANY rank needs generation for a rollout index, ALL ranks must participate
            if torch.distributed.is_initialized():
                global_needs_generation = local_needs_generation.clone()
                torch.distributed.all_reduce(global_needs_generation, op=torch.distributed.ReduceOp.MAX)
            else:
                global_needs_generation = local_needs_generation

            print(f"[FFR] Rank {torch.distributed.get_rank() if torch.distributed.is_initialized() else 0}: "
                  f"Local needs: {local_needs_generation.tolist()}, Global needs: {global_needs_generation.tolist()}")

            for rollout_idx in range(self.num_generations):
                is_correct = correct_mask[rollout_idx].item()
                needs_second_round = global_needs_generation[rollout_idx].item()

                print(f"[FFR] Processing rollout {rollout_idx}/{self.num_generations} "
                      f"(correct={is_correct >= 0.5}, needs_generation_globally={needs_second_round})")

                # [FFR FIX] Only call teacher API and prepare evidence if THIS rank needs it
                evidence = None
                if is_correct < 0.5:  # Incorrect rollout on this rank
                    print(f"[FFR] Rollout {rollout_idx} is incorrect on this rank, calling teacher API...")

                    # Get completion text
                    completion_text = completions[rollout_idx]
                    if is_conversational(inputs[0]):
                        completion_text = completion_text[0]["content"]

                    # Debug: Print actual field values
                    print(f"[FFR DEBUG] problem_id: {inputs[0].get('problem_id', 'MISSING')}")
                    print(f"[FFR DEBUG] problem: {inputs[0].get('problem', 'MISSING')[:50]}...")
                    print(f"[FFR DEBUG] solution: {inputs[0].get('solution', 'MISSING')[:50]}...")

                    # ==================== FFR Statistics: Teacher API ====================
                    self._ffr_stats['teacher_api_calls'] += 1
                    # =====================================================================

                    # Call teacher API
                    evidence = self._call_teacher_api(
                        problem_id=inputs[0].get('problem_id', f'unknown_{rollout_idx}'),
                        question=inputs[0].get('problem', ''),
                        video_path=inputs[0]['path'],
                        student_response=completion_text,
                        student_score=accuracy_rewards[rollout_idx].item(),
                        ground_truth=inputs[0].get('solution', ''),
                        data_source=inputs[0]['data_source']
                    )

                    # ==================== FFR Statistics: Teacher API Success ====================
                    if evidence:
                        self._ffr_stats['teacher_api_success'] += 1
                    # =============================================================================

                # [FFR FIX] If ANY rank needs second round generation, ALL ranks must participate
                # This is required for DeepSpeed ZeRO-3 where model parameters are sharded
                if needs_second_round:
                    if evidence:  # This rank actually needs the generation
                        print(f"[FFR] Starting second round generation for rollout {rollout_idx}...")

                        # ==================== FFR Statistics: Fix Attempt ====================
                        self._ffr_stats['fix_attempts'] += 1
                        # =====================================================================

                        try:
                            second_completion_text, second_completion_ids = self._generate_second_round_completion(
                                original_prompt_text=prompts_text[0],
                                evidence=evidence,
                                input_item=inputs[0],
                                model=model,
                                vision_inputs_for_ffr=vision_inputs_for_ffr  # [FFR FIX] Use pre-loaded vision inputs
                            )
                        except Exception as e:
                            print(f"[FFR ERROR] Second round generation failed for rollout {rollout_idx}: {e}")
                            import traceback
                            traceback.print_exc()
                            print(f"[FFR] Skipping second round for this rollout, keeping original reward")
                            continue

                        print(f"[FFR] Successfully generated second round completion for rollout {rollout_idx}")

                        # ==================== FFR Statistics: Second Round Tokens ====================
                        self._ffr_stats['total_second_round_tokens'] += second_completion_ids.numel()
                        # =============================================================================

                        # Compute reward for second round completion
                        second_completion_formatted = second_completion_text
                        if is_conversational(inputs[0]):
                            second_completion_formatted = [[{"role": "assistant", "content": second_completion_text}]]
                        else:
                            second_completion_formatted = [second_completion_text]

                        # Call reward functions for second round
                        second_rewards_per_func = torch.zeros(len(self.reward_funcs), device=device)
                        for i, (reward_func, reward_processing_class) in enumerate(
                            zip(self.reward_funcs, self.reward_processing_classes)
                        ):
                            reward_kwargs = {key: [inputs[0][key]] for key in inputs[0].keys()
                                           if key not in ["prompt", "completion"]}
                            output_reward = reward_func(
                                prompts=[prompts[0]],
                                completions=second_completion_formatted,
                                **reward_kwargs
                            )
                            second_rewards_per_func[i] = torch.tensor(output_reward[0], dtype=torch.float32, device=device)

                        second_round_reward = second_rewards_per_func.sum()

                        # ==================== FFR Statistics: Fix Success ====================
                        second_round_accuracy = second_rewards_per_func[0].item()
                        if second_round_accuracy >= 1.0:
                            self._ffr_stats['fix_success'] += 1
                        # =====================================================================

                        # Apply FFR formula: R̃_i = z_i * R(τ_i) + (1-z_i) * (R(τ_i*) - κ)
                        # Since is_correct=0, this simplifies to: R̃_i = R(τ_i*) - κ
                        corrected_rewards[rollout_idx] = second_round_reward - self.patch_tax

                        print(f"[FFR] Rollout {rollout_idx}: Original reward={rewards[rollout_idx]:.2f}, "
                              f"Second round reward={second_round_reward:.2f}, "
                              f"Corrected reward={corrected_rewards[rollout_idx]:.2f}, "
                              f"Fixed={'YES' if second_round_accuracy >= 1.0 else 'NO'}")
                    else:  # This rank doesn't need it, but must participate in generation
                        print(f"[FFR] Rank {torch.distributed.get_rank() if torch.distributed.is_initialized() else 0} "
                              f"participating in dummy generation for rollout {rollout_idx} (for DeepSpeed sync)")
                        try:
                            # Call dummy generation with minimal prompt to participate in collective ops
                            dummy_evidence = "N/A"
                            _ = self._generate_second_round_completion(
                                original_prompt_text=prompts_text[0],
                                evidence=dummy_evidence,
                                input_item=inputs[0],
                                model=model,
                                vision_inputs_for_ffr=vision_inputs_for_ffr  # [FFR FIX] Use pre-loaded vision inputs
                            )
                            # Discard the result - we don't update rewards for this rank
                        except Exception as e:
                            print(f"[FFR] Dummy generation failed (this is OK): {e}")
                            # It's OK if dummy generation fails - we don't need the result

            # Use corrected rewards for advantage computation
            rewards = corrected_rewards
            print(f"[FFR] Final corrected rewards: {rewards}")

            # Synchronize all GPUs after FFR to avoid timeout
            if torch.distributed.is_initialized():
                print(f"[FFR] Rank {torch.distributed.get_rank()} waiting for other ranks to finish FFR...")
                torch.distributed.barrier()
                print(f"[FFR] Rank {torch.distributed.get_rank()} synchronized, continuing training...")

        # Compute grouped-wise rewards
        mean_grouped_rewards = rewards.view(-1, self.num_generations).mean(dim=1)
        std_grouped_rewards = rewards.view(-1, self.num_generations).std(dim=1)

        # Normalize the rewards to compute the advantages
        mean_grouped_rewards = mean_grouped_rewards.repeat_interleave(self.num_generations, dim=0)
        std_grouped_rewards = std_grouped_rewards.repeat_interleave(self.num_generations, dim=0)
        advantages = (rewards - mean_grouped_rewards) / (std_grouped_rewards + 1e-4)

        # x - x.detach() allows for preserving gradients from x
        per_token_loss = torch.exp(per_token_logps - per_token_logps.detach()) * advantages.unsqueeze(1)
        per_token_loss = -(per_token_loss - self.beta * per_token_kl)
        # per_token_loss = -per_token_loss
        loss = ((per_token_loss * completion_mask).sum(dim=1) / completion_mask.sum(dim=1)).mean()

        # Log the metrics
        completion_length = self.accelerator.gather_for_metrics(completion_mask.sum(1)).float().mean().item()
        self._metrics["completion_length"].append(completion_length)

        reward_per_func = self.accelerator.gather_for_metrics(rewards_per_func).mean(0)
        for i, reward_func in enumerate(self.reward_funcs):
            if isinstance(reward_func, PreTrainedModel):
                reward_func_name = reward_func.config._name_or_path.split("/")[-1]
            else:
                reward_func_name = reward_func.__name__
            self._metrics[f"rewards/{reward_func_name}"].append(reward_per_func[i].item())

        gathered_rewards = self.accelerator.gather_for_metrics(rewards)

        num_devices = gathered_rewards.size(0) // self.num_generations
        rewards_per_device = gathered_rewards.view(num_devices, self.num_generations)
        wrong_devices = (rewards_per_device <= 1).all(dim=1)
        wrong_ratio = wrong_devices.sum().item() / num_devices

        correct_devices = (rewards_per_device >= 2).all(dim=1)
        correct_ratio = correct_devices.sum().item() / num_devices

        self._metrics["all_wrong"].append(wrong_ratio)
        self._metrics["all_correct"].append(correct_ratio)

        self._metrics["reward"].append(self.accelerator.gather_for_metrics(rewards).mean().item())

        self._metrics["reward_std"].append(self.accelerator.gather_for_metrics(std_grouped_rewards).mean().item())

        mean_kl = ((per_token_kl * completion_mask).sum(dim=1) / completion_mask.sum(dim=1)).mean()
        self._metrics["kl"].append(self.accelerator.gather_for_metrics(mean_kl).mean().item())

        # ==================== FFR Metrics Logging ====================
        if self.use_ffr:
            total_rollouts = self._ffr_stats['total_rollouts']
            incorrect_rollouts = self._ffr_stats['incorrect_rollouts']
            teacher_api_calls = self._ffr_stats['teacher_api_calls']
            teacher_api_success = self._ffr_stats['teacher_api_success']
            fix_attempts = self._ffr_stats['fix_attempts']
            fix_success = self._ffr_stats['fix_success']

            incorrect_ratio = incorrect_rollouts / max(1, total_rollouts)
            self._metrics["ffr/incorrect_rollouts_ratio"].append(incorrect_ratio)

            teacher_success_rate = teacher_api_success / max(1, teacher_api_calls)
            self._metrics["ffr/teacher_api_success_rate"].append(teacher_success_rate)

            fix_success_rate = fix_success / max(1, fix_attempts)
            self._metrics["ffr/fix_success_rate"].append(fix_success_rate)

            self._metrics["ffr/total_prompt_tokens"].append(self._ffr_stats['total_prompt_tokens'])
            self._metrics["ffr/total_completion_tokens"].append(self._ffr_stats['total_completion_tokens'])
            self._metrics["ffr/total_second_round_tokens"].append(self._ffr_stats['total_second_round_tokens'])

            self._metrics["ffr/incorrect_rollouts_count"].append(incorrect_rollouts)
            self._metrics["ffr/teacher_api_calls"].append(teacher_api_calls)
            self._metrics["ffr/fix_attempts"].append(fix_attempts)
            self._metrics["ffr/fix_success_count"].append(fix_success)

            # Reset stats counters after each batch
            for key in self._ffr_stats:
                self._ffr_stats[key] = 0
        # =============================================================

        return loss

    def log(self, logs: dict[str, float], start_time: Optional[float] = None) -> None:
        metrics = {key: sum(val) / len(val) for key, val in self._metrics.items()}  # average the metrics
        logs = {**logs, **metrics}
        if version.parse(transformers.__version__) >= version.parse("4.47.0.dev0"):
            super().log(logs, start_time)
        else:  # transformers<=4.46
            super().log(logs)
        self._metrics.clear()

    def create_model_card(
            self,
            model_name: Optional[str] = None,
            dataset_name: Optional[str] = None,
            tags: Union[str, list[str], None] = None,
    ):
        """
        Creates a draft of a model card using the information available to the `Trainer`.

        Args:
            model_name (`str` or `None`, *optional*, defaults to `None`):
                Name of the model.
            dataset_name (`str` or `None`, *optional*, defaults to `None`):
                Name of the dataset used for train.
            tags (`str`, `list[str]` or `None`, *optional*, defaults to `None`):
                Tags to be associated with the model card.
        """
        if not self.is_world_process_zero():
            return

        if hasattr(self.model.config, "_name_or_path") and not os.path.isdir(self.model.config._name_or_path):
            base_model = self.model.config._name_or_path
        else:
            base_model = None

        tags = tags or []
        if isinstance(tags, str):
            tags = [tags]

        if hasattr(self.model.config, "unsloth_version"):
            tags.append("unsloth")

        citation = textwrap.dedent(
            """\
            @article{zhihong2024deepseekmath,
                title        = {{DeepSeekMath: Pushing the Limits of Mathematical Reasoning in Open Language Models}},
                author       = {Zhihong Shao and Peiyi Wang and Qihao Zhu and Runxin Xu and Junxiao Song and Mingchuan Zhang and Y. K. Li and Y. Wu and Daya Guo},
                year         = 2024,
                eprint       = {arXiv:2402.03300},
            """
        )

        model_card = generate_model_card(
            base_model=base_model,
            model_name=model_name,
            hub_model_id=self.hub_model_id,
            dataset_name=dataset_name,
            tags=tags,
            wandb_url=wandb.run.get_url() if is_wandb_available() and wandb.run is not None else None,
            comet_url=get_comet_experiment_url(),
            trainer_name="GRPO",
            trainer_citation=citation,
            paper_title="DeepSeekMath: Pushing the Limits of Mathematical Reasoning in Open Language Models",
            paper_id="2402.03300",
        )

        model_card.save(os.path.join(self.args.output_dir, "README.md"))
